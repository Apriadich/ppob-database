
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dashboard Admin E-Commerce',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const StaffManagementPage(),
    );
  }
}

class StaffManagementPage extends StatelessWidget {
  const StaffManagementPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kontrol Staff E-Commerce'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          StaffCard(name: 'Staff 1', role: 'Admin Produk'),
          StaffCard(name: 'Staff 2', role: 'Customer Support'),
          StaffCard(name: 'Staff 3', role: 'Pengelola Promo'),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Aksi tambah staff baru
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}

class StaffCard extends StatelessWidget {
  final String name;
  final String role;

  const StaffCard({required this.name, required this.role, super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12.0),
      child: ListTile(
        title: Text(name),
        subtitle: Text(role),
        trailing: IconButton(
          icon: const Icon(Icons.edit),
          onPressed: () {
            // Aksi edit staff
          },
        ),
      ),
    );
  }
}
