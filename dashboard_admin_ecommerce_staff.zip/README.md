
# Dashboard Admin E-Commerce

Dashboard ini dibangun menggunakan Flutter Web untuk mengelola toko online dan kontrol staff.

## Fitur

- Kontrol staff/admin E-Commerce
- Ditujukan untuk dikembangkan lebih lanjut (produk, order, dll)

## Menjalankan Aplikasi

```bash
flutter config --enable-web
flutter pub get
flutter run -d chrome
```

## Struktur Proyek

- `lib/main.dart` — Halaman kontrol staff
