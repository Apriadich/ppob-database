// Konfigurasi aplikasi
package config

var DB_URL = "postgres://user:pass@localhost:5432/dbname"