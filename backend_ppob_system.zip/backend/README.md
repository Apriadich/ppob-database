# Backend PPOB

Struktur backend PPOB dengan Golang + PostgreSQL