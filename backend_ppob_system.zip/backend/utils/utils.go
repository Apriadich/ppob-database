// Utility functions
package utils