
# Flutter PPOB Frontend

Frontend aplikasi PPOB menggunakan Flutter.

## Integrasi Backend

Semua komunikasi frontend Flutter ke backend Golang dilakukan melalui API berbasis REST.

### Contoh Endpoint
- **Login:** `POST /api/auth/login`
- **Ambil Produk:** `GET /api/products/{kategori}` (kategori: prabayar/pascabayar)
- **Transaksi:** `POST /api/transaction`

### Konfigurasi
Pastikan backend berjalan di `http://localhost:8080` atau sesuaikan di file `lib/services/api_service.dart`.

### Dependencies Flutter:
Tambahkan di `pubspec.yaml`:
```yaml
dependencies:
  http: ^0.14.0
```
