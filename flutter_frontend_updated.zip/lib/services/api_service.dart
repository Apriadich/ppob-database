
import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'http://localhost:8080/api';

  Future<List<dynamic>> fetchProducts(String category) async {
    final response = await http.get(Uri.parse('\$baseUrl/products/\$category'));

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load products');
    }
  }

  Future<bool> login(String username, String password) async {
    final response = await http.post(
      Uri.parse('\$baseUrl/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({'username': username, 'password': password}),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return true;
    } else {
      return false;
    }
  }

  Future<bool> createTransaction(Map<String, dynamic> payload) async {
    final response = await http.post(
      Uri.parse('\$baseUrl/transaction'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(payload),
    );

    return response.statusCode == 200;
  }
}
