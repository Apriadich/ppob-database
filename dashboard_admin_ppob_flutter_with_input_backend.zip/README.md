
# Dashboard Admin PPOB (Flutter)

Proyek ini adalah dashboard admin berbasis Flutter untuk mengelola produk PPOB (Prabayar & Pascabayar).

## Fitur

- Halaman Produk Prabayar
- Halaman Produk Pascabayar

## Integrasi Backend

Gunakan service API (di `lib/services`) untuk menghubungkan dengan backend Golang.

Contoh endpoint:
- `/api/prabayar` untuk ambil data prabayar
- `/api/pascabayar` untuk ambil data pascabayar

Kembangkan file model dan widget untuk menampilkan data dari backend.

---

**Struktur Awal Sudah Siap Dikonfigurasi di Visual Studio Code**


## Fitur Tambahan

### Input Produk PPOB
- Form input untuk menambahkan produk prabayar atau pascabayar.
- Data dikirim ke backend menggunakan HTTP POST ke endpoint seperti `/api/products`.

### Integrasi Backend (Contoh)
Gunakan package `http` untuk integrasi backend:
```dart
import 'package:http/http.dart' as http;
final response = await http.post(
  Uri.parse('http://localhost:8000/api/products'),
  body: {'nama': nama, 'kategori': kategori, 'harga': harga},
);
```
