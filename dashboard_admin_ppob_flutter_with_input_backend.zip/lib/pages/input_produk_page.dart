
import 'package:flutter/material.dart';

class InputProdukPage extends StatelessWidget {
  const InputProdukPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Tambah Produk PPOB")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(decoration: InputDecoration(labelText: 'Nama Produk')),
            TextField(decoration: InputDecoration(labelText: 'Kategori')),
            TextField(decoration: InputDecoration(labelText: 'Harga')),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // TODO: Kirim ke backend dengan HTTP POST
              },
              child: const Text('Simpan Produk'),
            )
          ],
        ),
      ),
    );
  }
}
