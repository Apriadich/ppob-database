
import 'package:flutter/material.dart';

class PascabayarPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Produk Pascabayar')),
      body: Center(child: Text('Daftar produk pascabayar akan ditampilkan di sini.')),
    );
  }
}
