
import 'package:flutter/material.dart';

class PrabayarPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Produk Prabayar')),
      body: Center(child: Text('Daftar produk prabayar akan ditampilkan di sini.')),
    );
  }
}
