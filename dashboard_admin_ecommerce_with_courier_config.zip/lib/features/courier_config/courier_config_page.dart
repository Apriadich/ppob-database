
import 'package:flutter/material.dart';

class CourierConfigPage extends StatelessWidget {
  const CourierConfigPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Konfigurasi Kurir")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("Pilih Kurir yang Tersedia", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Expanded(
              child: ListView(
                children: [
                  CheckboxListTile(title: const Text("JNE"), value: true, onChanged: (val) {}),
                  CheckboxListTile(title: const Text("TIKI"), value: true, onChanged: (val) {}),
                  CheckboxListTile(title: const Text("POS Indonesia"), value: false, onChanged: (val) {}),
                  CheckboxListTile(title: const Text("SiCepat"), value: true, onChanged: (val) {}),
                  CheckboxListTile(title: const Text("J&T Express"), value: true, onChanged: (val) {}),
                  CheckboxListTile(title: const Text("Ninja Xpress"), value: false, onChanged: (val) {}),
                ],
              ),
            ),
            ElevatedButton(
              onPressed: () {},
              child: const Text("Simpan Konfigurasi"),
            ),
          ],
        ),
      ),
    );
  }
}
