
import 'package:flutter/material.dart';

class PrabayarScreen extends StatelessWidget {
  const PrabayarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('PPOB Prabayar')),
      body: const Center(
        child: Text('Halaman PPOB Prabayar'),
      ),
    );
  }
}
