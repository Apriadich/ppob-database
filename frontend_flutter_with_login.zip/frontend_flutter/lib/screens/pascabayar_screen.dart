
import 'package:flutter/material.dart';

class PascabayarScreen extends StatelessWidget {
  const PascabayarScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('PPOB Pascabayar')),
      body: const Center(
        child: Text('Halaman PPOB Pascabayar'),
      ),
    );
  }
}
