
# Flutter Frontend for PPOB App

## Overview
This is the Flutter frontend for the PPOB (Payment Point Online Bank) system.

## Features
- Basic home screen layout
- Ready for integration with backend (Golang)
- Can run on Android, iOS, Web, Desktop

## Requirements
- Flutter SDK
- Android Studio or Visual Studio Code

## Getting Started

```bash
flutter pub get
flutter run
```

You can modify the screens in `lib/screens` and add logic accordingly.


## Screens Included
- Login Screen
- Home Screen
- PPOB Prabayar
- PPOB Pascabayar
