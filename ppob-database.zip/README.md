# PPOB Database (PostgreSQL)

Struktur database untuk aplikasi PPOB all-in-one.
