-- Tambahkan user dummy
INSERT INTO users (username, password, email) VALUES
('admin', 'hashed_password', 'admin@example.com');

-- Tambahkan produk PPOB dummy
INSERT INTO products (name, category, price, provider) VALUES
('Pulsa 5.000', 'pulsa', 5500, 'Telkomsel'),
('Token Listrik 20.000', 'listrik', 21000, 'PLN');
