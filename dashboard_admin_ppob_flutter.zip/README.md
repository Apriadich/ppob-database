
# Dashboard Admin PPOB - Flutter

Dashboard admin PPOB berbasis Flutter untuk mengatur produk prabayar dan pascabayar.

## Fitur

- Manajemen Produk Prabayar (Pulsa, Paket Data, dsb)
- Manajemen Produk Pascabayar (Listrik, Air, Telkom, dsb)
- Integrasi backend (siap sambung ke API Golang)
- UI Responsive berbasis Web

## Struktur Folder

- `lib/pages`: Halaman utama seperti dashboard, login, produk
- `lib/widgets`: Komponen UI
- `lib/models`: Data models
- `lib/services`: Koneksi ke backend/API

## Integrasi Backend

Untuk menghubungkan ke backend Golang:
- Sesuaikan `BASE_URL` di `lib/services/api_service.dart`
- Gunakan `http` package untuk request ke endpoint backend

## Cara Menjalankan

```bash
flutter pub get
flutter run -d chrome
```

