import 'package:flutter/material.dart';

class EcommerceAdminScreen extends StatelessWidget {
  const EcommerceAdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Admin Toko Online")),
      body: const Center(child: Text("Halaman pengaturan dashboard toko online")),
    );
  }
}
