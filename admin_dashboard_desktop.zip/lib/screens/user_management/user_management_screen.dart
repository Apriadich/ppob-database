import 'package:flutter/material.dart';

class UserManagementScreen extends StatelessWidget {
  const UserManagementScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Kelola User / Staff")),
      body: const Center(child: Text("Fitur kontrol user atau staff admin")),
    );
  }
}
