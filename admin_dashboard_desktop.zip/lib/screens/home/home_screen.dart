import 'package:flutter/material.dart';
import '../ppob_admin/ppob_admin_screen.dart';
import '../ecommerce_admin/ecommerce_admin_screen.dart';
import '../user_management/user_management_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Admin Dashboard")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const PPOBAdminScreen())),
              child: const Text("Kelola Admin PPOB"),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const EcommerceAdminScreen())),
              child: const Text("Kelola Admin Toko Online"),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const UserManagementScreen())),
              child: const Text("Kelola User / Staff"),
            ),
          ],
        ),
      ),
    );
  }
}
