import 'package:flutter/material.dart';

class PPOBAdminScreen extends StatelessWidget {
  const PPOBAdminScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Admin PPOB")),
      body: const Center(child: Text("Halaman pengaturan dashboard PPOB")),
    );
  }
}
