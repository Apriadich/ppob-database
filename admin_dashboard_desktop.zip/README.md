# Admin Dashboard Desktop (Flutter)

Dashboard utama untuk mengelola dua admin berbasis website:
- Admin PPOB
- Admin Toko Online / E-commerce
- Serta fitur kontrol untuk user/staff admin

## Struktur Fitur
- Halaman Utama dengan navigasi ke tiga fitur
- Masing-masing fitur ditampilkan dalam halaman terpisah
- Dibangun menggunakan Flutter dan dapat dikembangkan untuk platform desktop/web

## Menjalankan Proyek
```bash
flutter pub get
flutter run -d windows
```
