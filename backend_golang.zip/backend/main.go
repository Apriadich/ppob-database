
package main

import (
    "github.com/gin-gonic/gin"
    "backend/config"
    "backend/routes"
    "github.com/joho/godotenv"
    "log"
)

func main() {
    err := godotenv.Load()
    if err != nil {
        log.Fatal("Error loading .env file")
    }

    config.Connect()
    r := gin.Default()
    routes.SetupRoutes(r)
    r.Run()
}
